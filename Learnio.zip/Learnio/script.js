//log in form script
var x=document.getElementById("login");
var y=document.getElementById("register");
var z=document.getElementById("btn");
                          
function register()
        {
          x.style.left="-400px";
          y.style.left="50px";
          z.style.left="110px";
        }
 function login()
          {
           x.style.left="50px";
           y.style.left="450px";
           z.style.left="0px";
          }
              //log in form script end
                              
                          

//Tutorial secton script
function openTopic(evt, topicName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(topicName).style.display = "block";
    evt.currentTarget.className += " active";
  }
  
  // Get the element with id="defaultOpen" and click on it
  document.getElementById("defaultOpen").click();
  //Tutorial secton script end


     